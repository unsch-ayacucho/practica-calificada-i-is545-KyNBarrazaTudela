package pe.edu.unsch.dao;

import java.util.List;

public interface CategoryDao {
	public List<>

}
