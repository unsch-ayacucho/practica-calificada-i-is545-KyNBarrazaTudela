package pe.edu.unsch.service;

public interface CategoryService {

}
