package pe.edu.unsch.dao;

public class CategoryDaoImpl {

}
